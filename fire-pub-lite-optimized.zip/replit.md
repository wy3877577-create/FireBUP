# FIRE PUB - Pakistani Battle Royale Game Website

## Overview

FIRE PUB is a full-stack web application for a Pakistani-themed battle royale game. The application serves as both a landing page and a player portal, featuring game information, character galleries, leaderboards, community features, and download links. The system uses modern web technologies with a focus on user experience and community engagement.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

The application follows a modern full-stack architecture with clear separation between client and server components:

- **Frontend**: React-based SPA with TypeScript, built using Vite
- **Backend**: Express.js REST API server with TypeScript
- **Database**: PostgreSQL with Drizzle ORM
- **Authentication**: Replit OAuth integration
- **Styling**: Tailwind CSS with shadcn/ui components
- **State Management**: TanStack Query for server state management

## Key Components

### Frontend Architecture
- **Framework**: React 18 with TypeScript and Vite bundler
- **Routing**: Wouter for lightweight client-side routing
- **UI Library**: shadcn/ui components built on Radix UI primitives
- **Styling**: Tailwind CSS with custom theming for gaming aesthetics
- **Animations**: Framer Motion for interactive animations
- **State Management**: TanStack Query for server state, React hooks for client state

### Backend Architecture
- **Framework**: Express.js with TypeScript
- **Database ORM**: Drizzle ORM with PostgreSQL
- **Authentication**: Passport.js with OpenID Connect (Replit Auth)
- **Session Management**: Express session with PostgreSQL store
- **API Design**: RESTful endpoints with consistent error handling

### Database Schema
The application uses PostgreSQL with the following main tables:
- **sessions**: Session storage (required for Replit Auth)
- **users**: User profiles with OAuth integration
- **playerStats**: Game statistics and leaderboard data
- **tournaments**: Tournament information
- **communityPosts**: Community content and discussions

### Authentication System
- **Provider**: Replit OAuth via OpenID Connect
- **Session Storage**: PostgreSQL-backed sessions with automatic cleanup
- **Authorization**: Route-level protection with middleware
- **User Management**: Automatic user creation and profile synchronization

## Data Flow

1. **User Authentication**: Users authenticate via Replit OAuth, creating or updating their profile in the database
2. **Player Statistics**: Game stats are tracked and updated through protected API endpoints
3. **Leaderboards**: Real-time leaderboard data aggregated from player statistics
4. **Community Features**: User-generated content stored and retrieved through the API
5. **Client-Server Communication**: RESTful API calls with automatic error handling and retry logic

## External Dependencies

### Frontend Dependencies
- **UI Components**: Radix UI primitives for accessibility
- **Animations**: Framer Motion for smooth transitions
- **Icons**: Lucide React and Font Awesome
- **HTTP Client**: Built-in fetch with TanStack Query wrapper
- **Form Handling**: React Hook Form with Zod validation

### Backend Dependencies
- **Database**: Neon serverless PostgreSQL
- **Authentication**: OpenID Client for OAuth integration
- **Session Store**: connect-pg-simple for PostgreSQL session storage
- **Security**: Built-in Express security middleware

### Development Tools
- **Build System**: Vite with TypeScript compilation
- **Database Migrations**: Drizzle Kit for schema management
- **Development Server**: Concurrent client/server development setup

## Deployment Strategy

The application is designed for deployment on Replit with the following considerations:

1. **Environment Variables**: 
   - `DATABASE_URL`: PostgreSQL connection string
   - `SESSION_SECRET`: Session encryption key
   - `REPLIT_DOMAINS`: Allowed domains for OAuth
   - `ISSUER_URL`: OAuth provider URL

2. **Build Process**:
   - Frontend: Vite builds optimized production bundle
   - Backend: esbuild compiles TypeScript to ESM format
   - Static files served from dist/public directory

3. **Database Setup**:
   - Automatic schema migration via Drizzle
   - Session table automatically managed
   - Connection pooling for serverless deployment

4. **Security Features**:
   - HTTPS-only cookies in production
   - CORS protection with domain validation
   - SQL injection protection via parameterized queries
   - Session-based authentication with automatic cleanup

The architecture prioritizes scalability, maintainability, and developer experience while providing a robust foundation for the gaming community platform.