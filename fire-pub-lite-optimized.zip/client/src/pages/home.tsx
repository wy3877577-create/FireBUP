import { useAuth } from "@/hooks/useAuth";
import { useQuery } from "@tanstack/react-query";
import Navigation from "@/components/ui/navigation";
import HeroSection from "@/components/sections/hero";
import GameOverview from "@/components/sections/game-overview";
import BattleMap from "@/components/sections/battle-map";
import CharacterGallery from "@/components/sections/character-gallery";
import DownloadSection from "@/components/sections/download";
import LeaderboardSection from "@/components/sections/leaderboard";
import CommunitySection from "@/components/sections/community";
import Footer from "@/components/sections/footer";

export default function Home() {
  const { user } = useAuth();
  
  const { data: playerStats } = useQuery({
    queryKey: ["/api/player/stats"],
    enabled: !!user,
  });

  return (
    <div className="min-h-screen bg-dark-navy text-white font-sans overflow-x-hidden">
      <Navigation />
      <HeroSection />
      <GameOverview />
      <BattleMap />
      <CharacterGallery />
      <DownloadSection />
      <LeaderboardSection />
      <CommunitySection />
      <Footer />
    </div>
  );
}
