import Navigation from "@/components/ui/navigation";
import LightweightHeroSection from "@/components/sections/lightweight-hero";
import { Button } from "@/components/ui/button";
import { Download, Users, Trophy, MapPin } from "lucide-react";

export default function LightweightLanding() {
  const gameFeatures = [
    { icon: <MapPin className="w-8 h-8" />, title: "Pakistani Maps", description: "Battle in Timergara valleys and tribal mountains", color: "text-[#FF6B35]" },
    { icon: <Users className="w-8 h-8" />, title: "Army Characters", description: "Play as Pakistani commandos and local warriors", color: "text-[#00FF88]" },
    { icon: <Trophy className="w-8 h-8" />, title: "Live Rankings", description: "Compete on real-time leaderboards", color: "text-[#FFD700]" }
  ];

  const downloadOptions = [
    { platform: "Android APK", size: "1.2 GB", requirements: "2GB RAM", icon: "fab fa-android", color: "text-[#00FF88]" },
    { platform: "PC Lite", size: "800 MB", requirements: "4GB RAM", icon: "fab fa-windows", color: "text-[#FF6B35]" }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#1A1A2E] via-[#16213E] to-[#0F3460] text-white font-sans">
      <Navigation />
      <LightweightHeroSection />
      
      {/* Features Section */}
      <section className="py-16 px-4">
        <div className="container mx-auto max-w-4xl">
          <h2 className="text-3xl font-bold text-center mb-12 text-transparent bg-clip-text bg-gradient-to-r from-[#FF6B35] to-[#FFD700]">
            Game Features
          </h2>
          <div className="grid md:grid-cols-3 gap-6">
            {gameFeatures.map((feature, index) => (
              <div key={index} className="bg-gradient-to-br from-[#0F3460] to-[#1A1A2E] p-6 rounded-xl border border-gray-700 hover:border-[#FF6B35] transition-colors">
                <div className={`${feature.color} mb-4`}>{feature.icon}</div>
                <h3 className="text-xl font-bold mb-2">{feature.title}</h3>
                <p className="text-gray-300 text-sm">{feature.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Quick Map Preview */}
      <section className="py-16 px-4 bg-gradient-to-r from-[#0F3460] to-[#16213E]">
        <div className="container mx-auto max-w-4xl text-center">
          <h2 className="text-3xl font-bold mb-8 text-transparent bg-clip-text bg-gradient-to-r from-[#FF6B35] to-[#FFD700]">
            Battle Zones
          </h2>
          <div className="grid md:grid-cols-3 gap-4">
            <div className="bg-[#1A1A2E] p-4 rounded-lg border border-[#FF6B35]">
              <div className="text-[#FF6B35] font-bold">Timergara Valley</div>
              <div className="text-sm text-gray-400">Military Zone</div>
            </div>
            <div className="bg-[#1A1A2E] p-4 rounded-lg border border-[#00FF88]">
              <div className="text-[#00FF88] font-bold">Medan Outpost</div>
              <div className="text-sm text-gray-400">Village Zone</div>
            </div>
            <div className="bg-[#1A1A2E] p-4 rounded-lg border border-[#FFD700]">
              <div className="text-[#FFD700] font-bold">Tribal Mountains</div>
              <div className="text-sm text-gray-400">Mountain Zone</div>
            </div>
          </div>
        </div>
      </section>

      {/* Lite Download Section */}
      <section className="py-16 px-4">
        <div className="container mx-auto max-w-4xl">
          <h2 className="text-3xl font-bold text-center mb-12 text-transparent bg-clip-text bg-gradient-to-r from-[#FF6B35] to-[#FFD700]">
            Download Lite Version
          </h2>
          <div className="grid md:grid-cols-2 gap-6">
            {downloadOptions.map((option, index) => (
              <div key={index} className="bg-gradient-to-br from-[#0F3460] to-[#1A1A2E] p-6 rounded-xl border border-gray-700 text-center">
                <div className={`text-4xl ${option.color} mb-4`}>
                  <i className={option.icon}></i>
                </div>
                <h3 className="text-xl font-bold mb-2">{option.platform}</h3>
                <div className="text-sm text-gray-400 mb-4">
                  <div>Size: {option.size}</div>
                  <div>Min: {option.requirements}</div>
                </div>
                <Button className="bg-gradient-to-r from-[#FF6B35] to-[#FFD700] w-full py-2 rounded-lg font-bold text-white">
                  <Download className="mr-2 h-4 w-4" />
                  Download {option.platform.split(' ')[0]}
                </Button>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Simple Footer */}
      <footer className="py-8 px-4 bg-[#1A1A2E] border-t border-gray-800">
        <div className="container mx-auto max-w-4xl text-center">
          <div className="flex items-center justify-center space-x-2 mb-4">
            <div className="w-6 h-6 bg-gradient-to-r from-[#FF6B35] to-[#FFD700] rounded flex items-center justify-center">
              <i className="fas fa-fire text-white text-sm"></i>
            </div>
            <h3 className="text-lg font-bold">FIRE PUB</h3>
          </div>
          <p className="text-sm text-gray-400">
            &copy; 2024 Fire PUB. Optimized for low-spec devices. Made for Pakistani gamers.
          </p>
        </div>
      </footer>
    </div>
  );
}