import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Download, Bell } from "lucide-react";

export default function DownloadSection() {
  const downloadOptions = [
    {
      platform: "Android APK",
      icon: "fab fa-android",
      description: "Download for Android devices. Compatible with Android 7.0+",
      size: "2.8 GB",
      version: "1.5.2",
      requirements: "4GB RAM",
      color: "text-[#00FF88]",
      available: true
    },
    {
      platform: "PC Windows",
      icon: "fab fa-windows",
      description: "Full PC experience with enhanced graphics and performance",
      size: "4.2 GB",
      version: "1.5.2",
      requirements: "8GB RAM",
      color: "text-[#FF6B35]",
      available: true
    },
    {
      platform: "iOS App Store",
      icon: "fab fa-apple",
      description: "Coming soon to iOS devices. Get notified when available",
      size: "In Review",
      version: "Q2 2024",
      requirements: "iOS 14+",
      color: "text-[#FFD700]",
      available: false
    }
  ];

  const systemRequirements = {
    minimum: [
      { icon: "fas fa-microchip", text: "Processor: Snapdragon 660 / A12 Bionic", color: "text-[#00FF88]" },
      { icon: "fas fa-memory", text: "RAM: 4GB", color: "text-[#00FF88]" },
      { icon: "fas fa-hdd", text: "Storage: 3GB free space", color: "text-[#00FF88]" },
      { icon: "fas fa-mobile-alt", text: "OS: Android 7.0 / iOS 14", color: "text-[#00FF88]" },
      { icon: "fas fa-wifi", text: "Network: Stable internet connection", color: "text-[#00FF88]" }
    ],
    recommended: [
      { icon: "fas fa-microchip", text: "Processor: Snapdragon 855+ / A14 Bionic", color: "text-[#FFD700]" },
      { icon: "fas fa-memory", text: "RAM: 8GB", color: "text-[#FFD700]" },
      { icon: "fas fa-hdd", text: "Storage: 5GB free space", color: "text-[#FFD700]" },
      { icon: "fas fa-mobile-alt", text: "OS: Android 11+ / iOS 15+", color: "text-[#FFD700]" },
      { icon: "fas fa-wifi", text: "Network: 5G / High-speed WiFi", color: "text-[#FFD700]" }
    ]
  };

  return (
    <section id="download" className="py-20 px-4 bg-gradient-to-r from-[#1A1A2E] via-[#16213E] to-[#0F3460]">
      <div className="container mx-auto max-w-6xl">
        <div className="text-center mb-16">
          <motion.h2 
            className="text-5xl font-bold mb-6 glow-text"
            initial={{ y: 50, opacity: 0 }}
            whileInView={{ y: 0, opacity: 1 }}
            transition={{ duration: 0.6 }}
            viewport={{ once: true }}
          >
            Download Fire PUB
          </motion.h2>
          <motion.p 
            className="text-xl text-gray-300 max-w-3xl mx-auto"
            initial={{ y: 50, opacity: 0 }}
            whileInView={{ y: 0, opacity: 1 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            viewport={{ once: true }}
          >
            Join the battle now! Available on multiple platforms for the ultimate gaming experience.
          </motion.p>
        </div>
        
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 mb-16">
          {downloadOptions.map((option, index) => (
            <motion.div 
              key={index}
              className={`character-card p-8 rounded-xl text-center ${!option.available ? 'opacity-60' : ''}`}
              initial={{ y: 50, opacity: 0 }}
              whileInView={{ y: 0, opacity: 1 }}
              transition={{ duration: 0.6, delay: index * 0.2 }}
              viewport={{ once: true }}
              whileHover={option.available ? { y: -10 } : {}}
            >
              <div className={`text-6xl ${option.color} mb-6`}>
                <i className={option.icon}></i>
              </div>
              <h3 className="text-2xl font-bold mb-4">{option.platform}</h3>
              <p className="text-gray-300 mb-6">{option.description}</p>
              <div className="text-sm text-gray-400 mb-6">
                <div>Size: {option.size}</div>
                <div>Version: {option.version}</div>
                <div>Requirements: {option.requirements}</div>
              </div>
              {option.available ? (
                <Button className="download-btn w-full py-3 rounded-lg font-bold text-white">
                  <Download className="mr-2 h-4 w-4" />
                  Download {option.platform.split(' ')[0]}
                </Button>
              ) : (
                <Button variant="outline" className="w-full py-3 border-2 border-[#FFD700] text-[#FFD700] rounded-lg font-bold">
                  <Bell className="mr-2 h-4 w-4" />
                  Notify Me
                </Button>
              )}
            </motion.div>
          ))}
        </div>
        
        {/* System Requirements */}
        <motion.div 
          className="bg-[#1A1A2E] rounded-2xl p-8"
          initial={{ y: 50, opacity: 0 }}
          whileInView={{ y: 0, opacity: 1 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
        >
          <h3 className="text-3xl font-bold mb-8 text-center glow-text">System Requirements</h3>
          <div className="grid md:grid-cols-2 gap-8">
            <div>
              <h4 className="text-xl font-bold mb-4 text-[#FF6B35]">Minimum Requirements</h4>
              <ul className="space-y-2 text-gray-300">
                {systemRequirements.minimum.map((req, index) => (
                  <li key={index} className="flex items-center">
                    <i className={`${req.icon} ${req.color} mr-2`}></i>
                    {req.text}
                  </li>
                ))}
              </ul>
            </div>
            <div>
              <h4 className="text-xl font-bold mb-4 text-[#FF6B35]">Recommended Requirements</h4>
              <ul className="space-y-2 text-gray-300">
                {systemRequirements.recommended.map((req, index) => (
                  <li key={index} className="flex items-center">
                    <i className={`${req.icon} ${req.color} mr-2`}></i>
                    {req.text}
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
