import { motion } from "framer-motion";
import { Crosshair, MapPin, Users } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function GameOverview() {
  const gameFeatures = [
    {
      icon: <Crosshair className="w-10 h-10" />,
      title: "Tactical Combat",
      description: "Use Pakistani military tactics and authentic weapons. Master the art of mountain warfare in challenging terrains inspired by real Pakistani locations.",
      color: "text-[#FF6B35]"
    },
    {
      icon: <MapPin className="w-10 h-10" />,
      title: "Authentic Locations",
      description: "Battle across meticulously recreated Pakistani landscapes including Timergara valleys, tribal mountain ranges, and strategic military outposts.",
      color: "text-[#00FF88]"
    },
    {
      icon: <Users className="w-10 h-10" />,
      title: "Cultural Heroes",
      description: "Play as Pakistani army commandos, tribal warriors, or local civilians. Each character brings unique skills and authentic cultural representation.",
      color: "text-[#FFD700]"
    }
  ];

  const gameModes = [
    { icon: "fas fa-user", title: "Solo Battle", description: "100 players, one survivor", color: "text-[#FF6B35]" },
    { icon: "fas fa-users", title: "Squad Wars", description: "4-player teams", color: "text-[#00FF88]" },
    { icon: "fas fa-flag", title: "Territory Control", description: "Capture and hold zones", color: "text-[#FFD700]" },
    { icon: "fas fa-stopwatch", title: "Blitz Mode", description: "Fast 10-minute battles", color: "text-[#FF6B35]" }
  ];

  return (
    <section id="overview" className="py-20 px-4">
      <div className="container mx-auto max-w-6xl">
        <div className="text-center mb-16">
          <motion.h2 
            className="text-5xl font-bold mb-6 glow-text"
            initial={{ y: 50, opacity: 0 }}
            whileInView={{ y: 0, opacity: 1 }}
            transition={{ duration: 0.6 }}
            viewport={{ once: true }}
          >
            Game Overview
          </motion.h2>
          <motion.p 
            className="text-xl text-gray-300 max-w-3xl mx-auto"
            initial={{ y: 50, opacity: 0 }}
            whileInView={{ y: 0, opacity: 1 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            viewport={{ once: true }}
          >
            Experience the thrill of battle royale in the breathtaking landscapes of Pakistan. 
            Fight with authentic Pakistani weapons and tactics.
          </motion.p>
        </div>
        
        <div className="grid md:grid-cols-3 gap-8 mb-16">
          {gameFeatures.map((feature, index) => (
            <motion.div 
              key={index}
              className="character-card p-8 rounded-xl"
              initial={{ y: 50, opacity: 0 }}
              whileInView={{ y: 0, opacity: 1 }}
              transition={{ duration: 0.6, delay: index * 0.2 }}
              viewport={{ once: true }}
              whileHover={{ y: -10 }}
            >
              <div className={`${feature.color} mb-4`}>
                {feature.icon}
              </div>
              <h3 className="text-2xl font-bold mb-4">{feature.title}</h3>
              <p className="text-gray-300">
                {feature.description}
              </p>
            </motion.div>
          ))}
        </div>
        
        {/* Game Modes */}
        <motion.div 
          className="bg-gradient-to-r from-[#1A1A2E] to-[#16213E] rounded-2xl p-8"
          initial={{ y: 50, opacity: 0 }}
          whileInView={{ y: 0, opacity: 1 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
        >
          <h3 className="text-3xl font-bold mb-8 text-center glow-text">Game Modes</h3>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {gameModes.map((mode, index) => (
              <motion.div 
                key={index}
                className="text-center p-6 bg-[#0F3460] rounded-xl hover:bg-opacity-80 transition-all cursor-pointer"
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
              >
                <i className={`${mode.icon} text-3xl ${mode.color} mb-4`}></i>
                <h4 className="font-bold mb-2">{mode.title}</h4>
                <p className="text-sm text-gray-300">{mode.description}</p>
              </motion.div>
            ))}
          </div>
        </motion.div>
      </div>
    </section>
  );
}
