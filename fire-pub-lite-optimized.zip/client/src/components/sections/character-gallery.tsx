import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";

export default function CharacterGallery() {
  const characters = [
    {
      name: "Colonel Shahid",
      role: "Pakistan Army Commando",
      image: "https://images.unsplash.com/photo-1506905925346-21bda4d32df4?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=400&h=500",
      stats: { combat: 95, stealth: 88, leadership: 92 },
      description: "Elite commando with expertise in mountain warfare and tactical operations.",
      color: "text-[#FF6B35]",
      rarity: 5
    },
    {
      name: "Khan Bahadur",
      role: "Tribal Mountain Warrior",
      image: "https://images.unsplash.com/photo-1506905925346-21bda4d32df4?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=400&h=500",
      stats: { survival: 98, tracking: 95, marksmanship: 90 },
      description: "Master of mountain terrain with unmatched survival instincts and local knowledge.",
      color: "text-[#00FF88]",
      rarity: 4
    },
    {
      name: "Dr. Fatima",
      role: "Field Medic",
      image: "https://images.unsplash.com/photo-1612349317150-e413f6a5b16d?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=400&h=500",
      stats: { healing: 99, speed: 85, support: 93 },
      description: "Expert medical support with ability to rapidly heal team members and provide tactical aid.",
      color: "text-[#FFD700]",
      rarity: 3
    }
  ];

  return (
    <section id="characters" className="py-20 px-4">
      <div className="container mx-auto max-w-6xl">
        <div className="text-center mb-16">
          <motion.h2 
            className="text-5xl font-bold mb-6 glow-text"
            initial={{ y: 50, opacity: 0 }}
            whileInView={{ y: 0, opacity: 1 }}
            transition={{ duration: 0.6 }}
            viewport={{ once: true }}
          >
            Character Gallery
          </motion.h2>
          <motion.p 
            className="text-xl text-gray-300 max-w-3xl mx-auto"
            initial={{ y: 50, opacity: 0 }}
            whileInView={{ y: 0, opacity: 1 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            viewport={{ once: true }}
          >
            Choose from authentic Pakistani characters, each with unique abilities and cultural backgrounds.
          </motion.p>
        </div>
        
        <div className="grid md:grid-cols-3 gap-8">
          {characters.map((character, index) => (
            <motion.div 
              key={index}
              className="character-card p-6 rounded-xl group"
              initial={{ y: 50, opacity: 0 }}
              whileInView={{ y: 0, opacity: 1 }}
              transition={{ duration: 0.6, delay: index * 0.2 }}
              viewport={{ once: true }}
              whileHover={{ y: -10 }}
            >
              <div className="relative mb-6 overflow-hidden rounded-lg">
                <img 
                  src={character.image} 
                  alt={character.name}
                  className="w-full h-64 object-cover group-hover:scale-110 transition-transform duration-300"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black to-transparent opacity-50"></div>
                <div className="absolute bottom-4 left-4">
                  <div className="flex space-x-1">
                    {Array.from({ length: 5 }).map((_, i) => (
                      <div 
                        key={i}
                        className={`w-2 h-2 rounded-full ${i < character.rarity ? character.color.replace('text-', 'bg-') : 'bg-gray-400'}`}
                      ></div>
                    ))}
                  </div>
                </div>
              </div>
              
              <h3 className="text-2xl font-bold mb-2">{character.name}</h3>
              <p className={`${character.color} font-semibold mb-4`}>{character.role}</p>
              
              <div className="space-y-2 text-sm mb-4">
                {Object.entries(character.stats).map(([stat, value]) => (
                  <div key={stat} className="flex justify-between">
                    <span className="text-gray-400 capitalize">{stat}:</span>
                    <span className="text-[#00FF88]">{value}/100</span>
                  </div>
                ))}
              </div>
              
              <p className="text-gray-300 text-sm">
                {character.description}
              </p>
            </motion.div>
          ))}
        </div>
        
        <motion.div 
          className="text-center mt-12"
          initial={{ y: 50, opacity: 0 }}
          whileInView={{ y: 0, opacity: 1 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
        >
          <Button variant="outline" className="px-8 py-4 border-2 border-[#FF6B35] text-[#FF6B35] rounded-lg hover:bg-[#FF6B35] hover:text-white transition-all font-bold">
            View All Characters
          </Button>
        </motion.div>
      </div>
    </section>
  );
}
