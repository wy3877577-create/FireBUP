import { motion } from "framer-motion";
import { useState } from "react";

export default function BattleMap() {
  const [selectedZone, setSelectedZone] = useState<string | null>(null);

  const battleZones = [
    { id: 'timergara', name: 'Timergara Valley', x: '33%', y: '25%', color: 'bg-[#FF6B35]', type: 'military' },
    { id: 'medan', name: 'Medan Outpost', x: '67%', y: '50%', color: 'bg-[#00FF88]', type: 'village' },
    { id: 'tribal', name: 'Tribal Mountains', x: '25%', y: '67%', color: 'bg-[#FFD700]', type: 'mountain' },
    { id: 'army-base', name: 'Army Base Alpha', x: '75%', y: '33%', color: 'bg-[#FF6B35]', type: 'military' },
    { id: 'border', name: 'Border Village', x: '67%', y: '75%', color: 'bg-[#00FF88]', type: 'village' }
  ];

  const zoneDetails = [
    {
      type: 'military',
      title: 'Military Zones',
      description: 'Heavily fortified areas with advanced weapons and tactical advantages. High risk, high reward locations.',
      color: 'bg-[#FF6B35]'
    },
    {
      type: 'village',
      title: 'Village Outposts',
      description: 'Local settlements with essential supplies and civilian equipment. Strategic locations for early game survival.',
      color: 'bg-[#00FF88]'
    },
    {
      type: 'mountain',
      title: 'Mountain Peaks',
      description: 'Elevated positions offering sniper advantages and panoramic views. Difficult terrain but superior tactical positioning.',
      color: 'bg-[#FFD700]'
    }
  ];

  return (
    <section id="map" className="py-20 px-4 bg-gradient-to-b from-[#1A1A2E] to-[#16213E]">
      <div className="container mx-auto max-w-6xl">
        <div className="text-center mb-16">
          <motion.h2 
            className="text-5xl font-bold mb-6 glow-text"
            initial={{ y: 50, opacity: 0 }}
            whileInView={{ y: 0, opacity: 1 }}
            transition={{ duration: 0.6 }}
            viewport={{ once: true }}
          >
            Pakistani Battle Map
          </motion.h2>
          <motion.p 
            className="text-xl text-gray-300 max-w-3xl mx-auto"
            initial={{ y: 50, opacity: 0 }}
            whileInView={{ y: 0, opacity: 1 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            viewport={{ once: true }}
          >
            Explore the diverse battlegrounds across Pakistan. From mountainous tribal areas to urban settlements.
          </motion.p>
        </div>
        
        <motion.div 
          className="relative bg-[#0F3460] rounded-2xl p-8 mb-8"
          initial={{ y: 50, opacity: 0 }}
          whileInView={{ y: 0, opacity: 1 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
        >
          {/* Interactive map */}
          <div 
            className="relative rounded-2xl overflow-hidden"
            style={{
              backgroundImage: 'url("https://images.unsplash.com/photo-1578662996442-48f60103fc96?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1200&h=800")',
              backgroundSize: 'cover',
              backgroundPosition: 'center',
              height: '500px',
              opacity: 0.7
            }}
          >
            <div className="absolute inset-0 bg-gradient-to-b from-transparent to-[#1A1A2E] opacity-50 rounded-2xl"></div>
            
            {/* Interactive battle zones */}
            {battleZones.map((zone) => (
              <motion.div
                key={zone.id}
                className="absolute map-zone cursor-pointer"
                style={{ left: zone.x, top: zone.y }}
                whileHover={{ scale: 1.2 }}
                whileTap={{ scale: 0.9 }}
                onClick={() => setSelectedZone(zone.id)}
              >
                <div className={`w-4 h-4 ${zone.color} rounded-full animate-pulse-glow`}></div>
                <div className="text-xs mt-1 font-bold whitespace-nowrap">{zone.name}</div>
              </motion.div>
            ))}
          </div>
        </motion.div>
        
        {/* Zone Details */}
        <div className="grid md:grid-cols-3 gap-6">
          {zoneDetails.map((zone, index) => (
            <motion.div 
              key={index}
              className="stats-card p-6 rounded-xl"
              initial={{ y: 50, opacity: 0 }}
              whileInView={{ y: 0, opacity: 1 }}
              transition={{ duration: 0.6, delay: index * 0.2 }}
              viewport={{ once: true }}
            >
              <div className="flex items-center mb-4">
                <div className={`w-3 h-3 ${zone.color} rounded-full mr-3`}></div>
                <h4 className="font-bold text-lg">{zone.title}</h4>
              </div>
              <p className="text-gray-300 text-sm">
                {zone.description}
              </p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
