import { Button } from "@/components/ui/button";
import { motion } from "framer-motion";
import { Download, Play } from "lucide-react";

export default function HeroSection() {
  return (
    <section id="home" className="relative min-h-screen flex items-center justify-center overflow-hidden">
      {/* Animated background */}
      <div className="absolute inset-0 battle-bg"></div>
      <div 
        className="absolute inset-0 opacity-30"
        style={{
          backgroundImage: 'url("https://images.unsplash.com/photo-1544735716-392fe2489ffa?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1920&h=1080")',
          backgroundSize: 'cover',
          backgroundPosition: 'center'
        }}
      ></div>
      <div className="absolute inset-0 hero-overlay"></div>
      
      {/* Animated particles */}
      <div className="absolute inset-0">
        {Array.from({ length: 5 }).map((_, i) => (
          <motion.div
            key={i}
            className="particle"
            style={{
              left: `${10 + i * 20}%`,
              top: `${20 + i * 15}%`,
            }}
            animate={{
              y: [-10, 10, -10],
            }}
            transition={{
              duration: 4,
              repeat: Infinity,
              delay: i * 0.5,
            }}
          />
        ))}
      </div>
      
      <div className="relative z-10 text-center px-4 max-w-6xl mx-auto">
        <motion.h1 
          className="text-6xl md:text-8xl font-bold mb-6 glow-text"
          initial={{ y: 50, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ duration: 0.6 }}
        >
          FIRE PUB
        </motion.h1>
        
        <motion.p 
          className="text-xl md:text-2xl font-semibold mb-8 text-gray-300"
          initial={{ y: 50, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ duration: 0.6, delay: 0.2 }}
        >
          The Ultimate Pakistan Battle Royale Experience
        </motion.p>
        
        <motion.p 
          className="text-lg md:text-xl mb-12 max-w-3xl mx-auto text-gray-400"
          initial={{ y: 50, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ duration: 0.6, delay: 0.4 }}
        >
          Fight across the mountainous terrains of Pakistan. From the valleys of Timergara to the peaks of tribal areas, 
          engage in epic battles with Pakistani army commandos, rebels, and civilians in the most realistic battle royale ever created.
        </motion.p>
        
        <motion.div 
          className="flex flex-col md:flex-row gap-6 justify-center items-center mb-16"
          initial={{ y: 50, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ duration: 0.6, delay: 0.6 }}
        >
          <Button className="download-btn px-8 py-4 text-xl font-bold rounded-lg text-white">
            <Download className="mr-2 h-5 w-5" />
            DOWNLOAD NOW
          </Button>
          <Button variant="outline" className="px-8 py-4 text-xl font-bold border-2 border-[#00FF88] text-[#00FF88] rounded-lg hover:bg-[#00FF88] hover:text-black">
            <Play className="mr-2 h-5 w-5" />
            WATCH TRAILER
          </Button>
        </motion.div>
        
        {/* Game Stats */}
        <motion.div 
          className="grid grid-cols-2 md:grid-cols-4 gap-8"
          initial={{ y: 50, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ duration: 0.6, delay: 0.8 }}
        >
          <div className="text-center">
            <div className="text-3xl md:text-4xl font-bold text-[#FF6B35]">500K+</div>
            <div className="text-gray-400">Active Players</div>
          </div>
          <div className="text-center">
            <div className="text-3xl md:text-4xl font-bold text-[#00FF88]">100+</div>
            <div className="text-gray-400">Battle Zones</div>
          </div>
          <div className="text-center">
            <div className="text-3xl md:text-4xl font-bold text-[#FFD700]">50+</div>
            <div className="text-gray-400">Characters</div>
          </div>
          <div className="text-center">
            <div className="text-3xl md:text-4xl font-bold text-[#FF6B35]">24/7</div>
            <div className="text-gray-400">Online Battles</div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
