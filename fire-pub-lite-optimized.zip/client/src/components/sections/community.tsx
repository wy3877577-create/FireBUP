import { motion } from "framer-motion";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { ExternalLink } from "lucide-react";

export default function CommunitySection() {
  const { data: recentPosts, isLoading } = useQuery({
    queryKey: ["/api/community/recent"],
  });

  const socialLinks = [
    {
      name: "Discord Server",
      icon: "fab fa-discord",
      members: "50K+ Members",
      color: "hover:bg-[#5865F2]",
      href: "#"
    },
    {
      name: "WhatsApp Groups",
      icon: "fab fa-whatsapp",
      members: "Regional Communities",
      color: "hover:bg-[#25D366] hover:text-black",
      href: "#"
    },
    {
      name: "Facebook Page",
      icon: "fab fa-facebook",
      members: "Official Updates",
      color: "hover:bg-[#1877F2]",
      href: "#"
    },
    {
      name: "YouTube Channel",
      icon: "fab fa-youtube",
      members: "Tutorials & Gameplay",
      color: "hover:bg-[#FF0000]",
      href: "#"
    }
  ];

  const communityStats = [
    { label: "Online Players", value: "47,892", color: "text-[#00FF88]" },
    { label: "Total Downloads", value: "2.4M", color: "text-[#FF6B35]" },
    { label: "Active Matches", value: "1,247", color: "text-[#FFD700]" },
    { label: "Tournament Prize Pool", value: "$125K", color: "text-[#FF6B35]" }
  ];

  const formatTimeAgo = (dateString: string) => {
    const date = new Date(dateString);
    const now = new Date();
    const diffInHours = Math.floor((now.getTime() - date.getTime()) / (1000 * 60 * 60));
    
    if (diffInHours < 1) return "Just now";
    if (diffInHours < 24) return `${diffInHours}h ago`;
    const diffInDays = Math.floor(diffInHours / 24);
    return `${diffInDays}d ago`;
  };

  return (
    <section id="community" className="py-20 px-4 bg-gradient-to-b from-[#16213E] to-[#1A1A2E]">
      <div className="container mx-auto max-w-6xl">
        <div className="text-center mb-16">
          <motion.h2 
            className="text-5xl font-bold mb-6 glow-text"
            initial={{ y: 50, opacity: 0 }}
            whileInView={{ y: 0, opacity: 1 }}
            transition={{ duration: 0.6 }}
            viewport={{ once: true }}
          >
            Community & News
          </motion.h2>
          <motion.p 
            className="text-xl text-gray-300 max-w-3xl mx-auto"
            initial={{ y: 50, opacity: 0 }}
            whileInView={{ y: 0, opacity: 1 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            viewport={{ once: true }}
          >
            Stay connected with the Fire PUB community. Get the latest updates, strategies, and events.
          </motion.p>
        </div>
        
        <div className="grid lg:grid-cols-3 gap-8">
          {/* Latest News */}
          <div className="lg:col-span-2">
            <motion.div 
              className="stats-card rounded-xl p-6 mb-8"
              initial={{ y: 50, opacity: 0 }}
              whileInView={{ y: 0, opacity: 1 }}
              transition={{ duration: 0.6 }}
              viewport={{ once: true }}
            >
              <h3 className="text-2xl font-bold mb-6">Latest News</h3>
              
              <div className="space-y-6">
                {isLoading ? (
                  <div className="text-center text-gray-400">Loading news...</div>
                ) : recentPosts && Array.isArray(recentPosts) && recentPosts.length > 0 ? (
                  recentPosts.map((post: any, index: number) => (
                    <motion.div 
                      key={post.id}
                      className="flex gap-4 p-4 bg-[#0F3460] rounded-lg hover:bg-opacity-80 transition-all cursor-pointer"
                      initial={{ x: -50, opacity: 0 }}
                      whileInView={{ x: 0, opacity: 1 }}
                      transition={{ duration: 0.4, delay: index * 0.1 }}
                      viewport={{ once: true }}
                      whileHover={{ x: 5 }}
                    >
                      {post.imageUrl && (
                        <img 
                          src={post.imageUrl} 
                          alt={post.title}
                          className="w-20 h-20 object-cover rounded-lg"
                        />
                      )}
                      <div className="flex-1">
                        <h4 className="font-bold text-[#FF6B35] mb-2">{post.title}</h4>
                        <p className="text-sm text-gray-300 mb-2 line-clamp-2">
                          {post.content}
                        </p>
                        <div className="text-xs text-gray-400">
                          {formatTimeAgo(post.createdAt)}
                          {post.author && ` • by ${post.author.firstName || 'Admin'}`}
                        </div>
                      </div>
                    </motion.div>
                  ))
                ) : (
                  <div className="space-y-6">
                    {/* Default news items when no posts available */}
                    <div className="flex gap-4 p-4 bg-[#0F3460] rounded-lg">
                      <img 
                        src="https://images.unsplash.com/photo-1542751371-adc38448a05e?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=300&h=200" 
                        alt="Game update" 
                        className="w-20 h-20 object-cover rounded-lg"
                      />
                      <div className="flex-1">
                        <h4 className="font-bold text-[#FF6B35] mb-2">Welcome to Fire PUB!</h4>
                        <p className="text-sm text-gray-300 mb-2">
                          Experience the ultimate Pakistan-themed battle royale with authentic locations and characters.
                        </p>
                        <div className="text-xs text-gray-400">Welcome Post</div>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            </motion.div>
          </div>
          
          {/* Community Panel */}
          <div className="space-y-6">
            {/* Social Links */}
            <motion.div 
              className="stats-card rounded-xl p-6"
              initial={{ y: 50, opacity: 0 }}
              whileInView={{ y: 0, opacity: 1 }}
              transition={{ duration: 0.6, delay: 0.2 }}
              viewport={{ once: true }}
            >
              <h3 className="text-xl font-bold mb-4">Join Community</h3>
              <div className="space-y-3">
                {socialLinks.map((link, index) => (
                  <motion.a 
                    key={index}
                    href={link.href}
                    className={`flex items-center p-3 bg-[#0F3460] rounded-lg ${link.color} transition-all group cursor-pointer`}
                    whileHover={{ x: 5 }}
                    whileTap={{ scale: 0.95 }}
                  >
                    <i className={`${link.icon} text-2xl mr-3 text-gray-400 group-hover:text-white`}></i>
                    <div className="flex-1">
                      <div className="font-bold">{link.name}</div>
                      <div className="text-sm text-gray-400 group-hover:text-white">{link.members}</div>
                    </div>
                    <ExternalLink className="w-4 h-4 opacity-0 group-hover:opacity-100 transition-opacity" />
                  </motion.a>
                ))}
              </div>
            </motion.div>
            
            {/* Community Stats */}
            <motion.div 
              className="stats-card rounded-xl p-6"
              initial={{ y: 50, opacity: 0 }}
              whileInView={{ y: 0, opacity: 1 }}
              transition={{ duration: 0.6, delay: 0.4 }}
              viewport={{ once: true }}
            >
              <h3 className="text-xl font-bold mb-4">Community Stats</h3>
              <div className="space-y-3">
                {communityStats.map((stat, index) => (
                  <div key={index} className="flex justify-between">
                    <span className="text-gray-400">{stat.label}:</span>
                    <span className={`${stat.color} font-bold`}>{stat.value}</span>
                  </div>
                ))}
              </div>
            </motion.div>
          </div>
        </div>
      </div>
    </section>
  );
}
