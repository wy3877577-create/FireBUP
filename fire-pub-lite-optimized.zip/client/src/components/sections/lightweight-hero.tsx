import { Button } from "@/components/ui/button";
import { Download, Play } from "lucide-react";

export default function LightweightHeroSection() {
  return (
    <section id="home" className="relative min-h-screen flex items-center justify-center overflow-hidden">
      {/* Simplified background */}
      <div className="absolute inset-0 bg-gradient-to-br from-[#1A1A2E] via-[#16213E] to-[#0F3460]"></div>
      
      <div className="relative z-10 text-center px-4 max-w-4xl mx-auto">
        <h1 className="text-4xl md:text-6xl font-bold mb-6 text-transparent bg-clip-text bg-gradient-to-r from-[#FF6B35] to-[#FFD700]">
          FIRE PUB
        </h1>
        
        <p className="text-lg md:text-xl font-semibold mb-6 text-gray-300">
          The Ultimate Pakistan Battle Royale Experience
        </p>
        
        <p className="text-base mb-8 max-w-2xl mx-auto text-gray-400">
          Fight across the mountainous terrains of Pakistan. From Timergara to tribal areas, 
          engage in epic battles with authentic Pakistani characters.
        </p>
        
        <div className="flex flex-col sm:flex-row gap-4 justify-center items-center mb-12">
          <Button className="bg-gradient-to-r from-[#FF6B35] to-[#FFD700] px-6 py-3 text-lg font-bold rounded-lg text-white hover:scale-105 transition-transform">
            <Download className="mr-2 h-4 w-4" />
            DOWNLOAD NOW
          </Button>
          <Button variant="outline" className="px-6 py-3 text-lg font-bold border-2 border-[#00FF88] text-[#00FF88] rounded-lg hover:bg-[#00FF88] hover:text-black">
            <Play className="mr-2 h-4 w-4" />
            WATCH TRAILER
          </Button>
        </div>
        
        {/* Simplified Stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-center">
          <div>
            <div className="text-2xl font-bold text-[#FF6B35]">500K+</div>
            <div className="text-sm text-gray-400">Players</div>
          </div>
          <div>
            <div className="text-2xl font-bold text-[#00FF88]">100+</div>
            <div className="text-sm text-gray-400">Zones</div>
          </div>
          <div>
            <div className="text-2xl font-bold text-[#FFD700]">50+</div>
            <div className="text-sm text-gray-400">Characters</div>
          </div>
          <div>
            <div className="text-2xl font-bold text-[#FF6B35]">24/7</div>
            <div className="text-sm text-gray-400">Online</div>
          </div>
        </div>
      </div>
    </section>
  );
}