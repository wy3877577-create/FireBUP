import { motion } from "framer-motion";
import { useQuery } from "@tanstack/react-query";
import { useAuth } from "@/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Trophy, Medal, Award } from "lucide-react";

export default function LeaderboardSection() {
  const { isAuthenticated } = useAuth();
  
  const { data: leaderboard, isLoading } = useQuery({
    queryKey: ["/api/leaderboard"],
    refetchInterval: 30000, // Refresh every 30 seconds
  });

  const { data: playerStats } = useQuery({
    queryKey: ["/api/player/stats"],
    enabled: isAuthenticated,
  });

  const { data: tournaments } = useQuery({
    queryKey: ["/api/tournaments"],
  });

  const getRankIcon = (rank: number) => {
    switch (rank) {
      case 1: return <Trophy className="w-6 h-6 text-[#FFD700]" />;
      case 2: return <Medal className="w-6 h-6 text-gray-400" />;
      case 3: return <Award className="w-6 h-6 text-[#CD7F32]" />;
      default: return <span className="text-gray-400 font-bold w-6 text-center">{rank}</span>;
    }
  };

  const getRankBg = (rank: number) => {
    switch (rank) {
      case 1: return "bg-gradient-to-r from-[#FFD700] to-[#FF6B35]";
      case 2: return "bg-[#0F3460]";
      case 3: return "bg-[#0F3460]";
      default: return "bg-[#0F3460]";
    }
  };

  return (
    <section id="leaderboard" className="py-20 px-4">
      <div className="container mx-auto max-w-6xl">
        <div className="text-center mb-16">
          <motion.h2 
            className="text-5xl font-bold mb-6 glow-text"
            initial={{ y: 50, opacity: 0 }}
            whileInView={{ y: 0, opacity: 1 }}
            transition={{ duration: 0.6 }}
            viewport={{ once: true }}
          >
            Live Leaderboard
          </motion.h2>
          <motion.p 
            className="text-xl text-gray-300 max-w-3xl mx-auto"
            initial={{ y: 50, opacity: 0 }}
            whileInView={{ y: 0, opacity: 1 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            viewport={{ once: true }}
          >
            See who dominates the Pakistani battlegrounds. Rankings update in real-time.
          </motion.p>
        </div>
        
        <div className="grid lg:grid-cols-3 gap-8">
          {/* Top Players */}
          <div className="lg:col-span-2">
            <motion.div 
              className="stats-card rounded-xl p-6"
              initial={{ y: 50, opacity: 0 }}
              whileInView={{ y: 0, opacity: 1 }}
              transition={{ duration: 0.6 }}
              viewport={{ once: true }}
            >
              <div className="flex justify-between items-center mb-6">
                <h3 className="text-2xl font-bold">Top Warriors</h3>
                <div className="flex space-x-2">
                  <Button size="sm" className="bg-[#FF6B35] text-white">Daily</Button>
                  <Button size="sm" variant="ghost" className="text-gray-400 hover:text-white">Weekly</Button>
                  <Button size="sm" variant="ghost" className="text-gray-400 hover:text-white">All Time</Button>
                </div>
              </div>
              
              <div className="space-y-4">
                {isLoading ? (
                  <div className="text-center text-gray-400">Loading leaderboard...</div>
                ) : leaderboard && Array.isArray(leaderboard) && leaderboard.length > 0 ? (
                  leaderboard.map((player: any, index: number) => (
                    <motion.div 
                      key={player.id}
                      className={`flex items-center p-4 ${getRankBg(index + 1)} rounded-lg`}
                      initial={{ x: -50, opacity: 0 }}
                      whileInView={{ x: 0, opacity: 1 }}
                      transition={{ duration: 0.4, delay: index * 0.1 }}
                      viewport={{ once: true }}
                    >
                      <div className="mr-4">
                        {getRankIcon(index + 1)}
                      </div>
                      <div className="w-12 h-12 bg-gray-600 rounded-full mr-4 overflow-hidden">
                        {player.user.profileImageUrl ? (
                          <img src={player.user.profileImageUrl} alt="Profile" className="w-full h-full object-cover" />
                        ) : (
                          <div className="w-full h-full bg-gray-600"></div>
                        )}
                      </div>
                      <div className="flex-1">
                        <div className="font-bold">
                          {player.user.firstName || player.user.email?.split('@')[0] || `Player${player.user.id.slice(-4)}`}
                        </div>
                        <div className="text-sm opacity-80">Rank #{index + 1}</div>
                      </div>
                      <div className="text-right">
                        <div className="font-bold">{player.wins || 0}</div>
                        <div className="text-sm opacity-80">Wins</div>
                      </div>
                    </motion.div>
                  ))
                ) : (
                  <div className="text-center text-gray-400">No leaderboard data available</div>
                )}
              </div>
            </motion.div>
          </div>
          
          {/* Stats Panel */}
          <div className="space-y-6">
            {/* Your Rank */}
            {isAuthenticated && (
              <motion.div 
                className="stats-card rounded-xl p-6"
                initial={{ y: 50, opacity: 0 }}
                whileInView={{ y: 0, opacity: 1 }}
                transition={{ duration: 0.6, delay: 0.2 }}
                viewport={{ once: true }}
              >
                <h3 className="text-xl font-bold mb-4">Your Stats</h3>
                <div className="space-y-3">
                  <div className="flex justify-between">
                    <span className="text-gray-400">Current Rank:</span>
                    <span className="text-[#FF6B35] font-bold">#{playerStats && 'rank' in playerStats ? playerStats.rank || 'Unranked' : 'Unranked'}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-400">Wins:</span>
                    <span className="text-[#00FF88]">{playerStats && 'wins' in playerStats ? playerStats.wins || 0 : 0}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-400">Kills:</span>
                    <span className="text-[#FFD700]">{playerStats && 'kills' in playerStats ? playerStats.kills || 0 : 0}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-400">Win Rate:</span>
                    <span className="text-[#FF6B35]">{playerStats && 'winRate' in playerStats && playerStats.winRate ? (playerStats.winRate / 100).toFixed(1) : '0.0'}%</span>
                  </div>
                </div>
              </motion.div>
            )}
            
            {/* Active Tournaments */}
            <motion.div 
              className="stats-card rounded-xl p-6"
              initial={{ y: 50, opacity: 0 }}
              whileInView={{ y: 0, opacity: 1 }}
              transition={{ duration: 0.6, delay: 0.4 }}
              viewport={{ once: true }}
            >
              <h3 className="text-xl font-bold mb-4">Active Tournaments</h3>
              <div className="space-y-4">
                {tournaments && Array.isArray(tournaments) && tournaments.length > 0 ? (
                  tournaments.slice(0, 2).map((tournament: any, index: number) => (
                    <div key={tournament.id} className="border border-[#FF6B35] rounded-lg p-3">
                      <div className="font-bold text-[#FF6B35]">{tournament.name}</div>
                      <div className="text-sm text-gray-400">Prize: ${tournament.prizePool?.toLocaleString() || '0'}</div>
                      <div className="text-xs text-[#00FF88]">Active Tournament</div>
                    </div>
                  ))
                ) : (
                  <div className="text-center text-gray-400">No active tournaments</div>
                )}
              </div>
            </motion.div>
          </div>
        </div>
      </div>
    </section>
  );
}
