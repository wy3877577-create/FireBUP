import { useAuth } from "@/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Menu, X } from "lucide-react";
import { useState } from "react";

export default function Navigation() {
  const { isAuthenticated, user } = useAuth();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
    setIsMobileMenuOpen(false);
  };

  return (
    <nav className="fixed top-0 w-full z-50 nav-glass">
      <div className="container mx-auto px-4 py-4">
        <div className="flex justify-between items-center">
          <div className="flex items-center space-x-2">
            <div className="w-10 h-10 bg-gradient-to-r from-[#FF6B35] to-[#FFD700] rounded-lg flex items-center justify-center">
              <i className="fas fa-fire text-white text-xl"></i>
            </div>
            <h1 className="text-2xl font-bold glow-text">FIRE PUB</h1>
          </div>
          
          <div className="hidden md:flex space-x-8">
            <button onClick={() => scrollToSection('home')} className="hover:text-[#FF6B35] transition-colors">Home</button>
            <button onClick={() => scrollToSection('overview')} className="hover:text-[#FF6B35] transition-colors">Game</button>
            <button onClick={() => scrollToSection('map')} className="hover:text-[#FF6B35] transition-colors">Battle Map</button>
            <button onClick={() => scrollToSection('characters')} className="hover:text-[#FF6B35] transition-colors">Characters</button>
            <button onClick={() => scrollToSection('download')} className="hover:text-[#FF6B35] transition-colors">Download</button>
            <button onClick={() => scrollToSection('leaderboard')} className="hover:text-[#FF6B35] transition-colors">Leaderboard</button>
            <button onClick={() => scrollToSection('community')} className="hover:text-[#FF6B35] transition-colors">Community</button>
          </div>
          
          <div className="hidden md:flex space-x-4">
            {isAuthenticated ? (
              <div className="flex items-center space-x-4">
                <div className="flex items-center space-x-2">
                  {user && 'profileImageUrl' in user && user.profileImageUrl && (
                    <img src={user.profileImageUrl} alt="Profile" className="w-8 h-8 rounded-full object-cover" />
                  )}
                  <span className="text-sm">Welcome, {user && 'firstName' in user ? user.firstName || 'Player' : 'Player'}</span>
                </div>
                <Button variant="outline" onClick={() => window.location.href = '/api/logout'}>
                  Logout
                </Button>
              </div>
            ) : (
              <>
                <Button variant="outline" onClick={() => window.location.href = '/api/login'}>
                  Login
                </Button>
                <Button className="bg-[#FF6B35] hover:bg-[#FF6B35]/80" onClick={() => window.location.href = '/api/login'}>
                  Sign Up
                </Button>
              </>
            )}
          </div>
          
          <div className="md:hidden">
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
            >
              {isMobileMenuOpen ? <X /> : <Menu />}
            </Button>
          </div>
        </div>
        
        {/* Mobile Menu */}
        {isMobileMenuOpen && (
          <div className="md:hidden mt-4 pt-4 border-t border-gray-800">
            <div className="flex flex-col space-y-4">
              <button onClick={() => scrollToSection('home')} className="text-left hover:text-[#FF6B35] transition-colors">Home</button>
              <button onClick={() => scrollToSection('overview')} className="text-left hover:text-[#FF6B35] transition-colors">Game</button>
              <button onClick={() => scrollToSection('map')} className="text-left hover:text-[#FF6B35] transition-colors">Battle Map</button>
              <button onClick={() => scrollToSection('characters')} className="text-left hover:text-[#FF6B35] transition-colors">Characters</button>
              <button onClick={() => scrollToSection('download')} className="text-left hover:text-[#FF6B35] transition-colors">Download</button>
              <button onClick={() => scrollToSection('leaderboard')} className="text-left hover:text-[#FF6B35] transition-colors">Leaderboard</button>
              <button onClick={() => scrollToSection('community')} className="text-left hover:text-[#FF6B35] transition-colors">Community</button>
              
              <div className="flex flex-col space-y-2 pt-4">
                {isAuthenticated ? (
                  <Button variant="outline" onClick={() => window.location.href = '/api/logout'}>
                    Logout
                  </Button>
                ) : (
                  <>
                    <Button variant="outline" onClick={() => window.location.href = '/api/login'}>
                      Login
                    </Button>
                    <Button className="bg-[#FF6B35] hover:bg-[#FF6B35]/80" onClick={() => window.location.href = '/api/login'}>
                      Sign Up
                    </Button>
                  </>
                )}
              </div>
            </div>
          </div>
        )}
      </div>
    </nav>
  );
}
