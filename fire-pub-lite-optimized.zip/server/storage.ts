import {
  users,
  playerStats,
  tournaments,
  communityPosts,
  type User,
  type UpsertUser,
  type PlayerStats,
  type InsertPlayerStats,
  type Tournament,
  type CommunityPost,
} from "@shared/schema";
import { db } from "./db";
import { eq, desc, sql } from "drizzle-orm";

// Interface for storage operations
export interface IStorage {
  // User operations (IMPORTANT) these user operations are mandatory for Replit Auth.
  getUser(id: string): Promise<User | undefined>;
  upsertUser(user: UpsertUser): Promise<User>;
  
  // Player stats operations
  getPlayerStats(userId: string): Promise<PlayerStats | undefined>;
  createPlayerStats(stats: InsertPlayerStats): Promise<PlayerStats>;
  updatePlayerStats(userId: string, stats: Partial<InsertPlayerStats>): Promise<PlayerStats>;
  getLeaderboard(limit?: number): Promise<(PlayerStats & { user: User })[]>;
  
  // Tournament operations
  getActiveTournaments(): Promise<Tournament[]>;
  getTournament(id: string): Promise<Tournament | undefined>;
  
  // Community operations
  getCommunityPosts(limit?: number): Promise<(CommunityPost & { author: User | null })[]>;
  getRecentPosts(limit?: number): Promise<(CommunityPost & { author: User | null })[]>;
}

export class DatabaseStorage implements IStorage {
  // User operations (IMPORTANT) these user operations are mandatory for Replit Auth.
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async upsertUser(userData: UpsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(userData)
      .onConflictDoUpdate({
        target: users.id,
        set: {
          ...userData,
          updatedAt: new Date(),
        },
      })
      .returning();
    return user;
  }

  // Player stats operations
  async getPlayerStats(userId: string): Promise<PlayerStats | undefined> {
    const [stats] = await db.select().from(playerStats).where(eq(playerStats.userId, userId));
    return stats;
  }

  async createPlayerStats(stats: InsertPlayerStats): Promise<PlayerStats> {
    const [playerStat] = await db.insert(playerStats).values(stats).returning();
    return playerStat;
  }

  async updatePlayerStats(userId: string, stats: Partial<InsertPlayerStats>): Promise<PlayerStats> {
    const [updatedStats] = await db
      .update(playerStats)
      .set({ ...stats, updatedAt: new Date() })
      .where(eq(playerStats.userId, userId))
      .returning();
    return updatedStats;
  }

  async getLeaderboard(limit: number = 10): Promise<(PlayerStats & { user: User })[]> {
    const results = await db
      .select({
        id: playerStats.id,
        userId: playerStats.userId,
        wins: playerStats.wins,
        kills: playerStats.kills,
        matches: playerStats.matches,
        rank: playerStats.rank,
        winRate: playerStats.winRate,
        createdAt: playerStats.createdAt,
        updatedAt: playerStats.updatedAt,
        user: users,
      })
      .from(playerStats)
      .innerJoin(users, eq(playerStats.userId, users.id))
      .orderBy(desc(playerStats.wins))
      .limit(limit);
    
    return results;
  }

  // Tournament operations
  async getActiveTournaments(): Promise<Tournament[]> {
    return await db
      .select()
      .from(tournaments)
      .where(eq(tournaments.isActive, true))
      .orderBy(desc(tournaments.startDate));
  }

  async getTournament(id: string): Promise<Tournament | undefined> {
    const [tournament] = await db.select().from(tournaments).where(eq(tournaments.id, id));
    return tournament;
  }

  // Community operations
  async getCommunityPosts(limit: number = 10): Promise<(CommunityPost & { author: User | null })[]> {
    const results = await db
      .select({
        id: communityPosts.id,
        title: communityPosts.title,
        content: communityPosts.content,
        imageUrl: communityPosts.imageUrl,
        authorId: communityPosts.authorId,
        category: communityPosts.category,
        isPublished: communityPosts.isPublished,
        createdAt: communityPosts.createdAt,
        updatedAt: communityPosts.updatedAt,
        author: users,
      })
      .from(communityPosts)
      .leftJoin(users, eq(communityPosts.authorId, users.id))
      .where(eq(communityPosts.isPublished, true))
      .orderBy(desc(communityPosts.createdAt))
      .limit(limit);
    
    return results;
  }

  async getRecentPosts(limit: number = 5): Promise<(CommunityPost & { author: User | null })[]> {
    return this.getCommunityPosts(limit);
  }
}

export const storage = new DatabaseStorage();
